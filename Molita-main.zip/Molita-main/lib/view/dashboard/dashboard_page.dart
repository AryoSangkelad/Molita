import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:salomon_bottom_bar/salomon_bottom_bar.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

import '../../viewmodels/dashboard_viewmodel.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int _currentIndex = 0;

  final PageController _pageController = PageController();
  Timer? _autoScrollTimer;

  @override
  void initState() {
    super.initState();
    _startAutoScroll();
  }

  void _startAutoScroll() {
    _autoScrollTimer = Timer.periodic(const Duration(seconds: 4), (timer) {
      if (_pageController.hasClients) {
        final viewModel = Provider.of<DashboardViewModel>(context, listen: false);
        int nextPage = _pageController.page!.round() + 1;
        if (nextPage >= viewModel.healthImages.length) nextPage = 0;
        _pageController.animateToPage(
          nextPage,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _autoScrollTimer?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = Provider.of<DashboardViewModel>(context);

    final List<Widget> _pages = [
      _buildMainDashboard(viewModel),
      Center(child: Text("Jadwal", style: TextStyle(fontSize: 24))),
      Center(child: Text("Edukasi", style: TextStyle(fontSize: 24))),
      Center(child: Text("Grafik", style: TextStyle(fontSize: 24))),
      Center(child: Text("Profil", style: TextStyle(fontSize: 24))),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFE1F5FE),
      body: _pages[_currentIndex],
      bottomNavigationBar: SalomonBottomBar(
        backgroundColor: Colors.blue,
        unselectedItemColor: Colors.white,
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        items: [
          SalomonBottomBarItem(icon: Icon(Icons.home), title: Text("Beranda"), selectedColor: Colors.white),
          SalomonBottomBarItem(icon: Icon(Icons.calendar_month), title: Text("Jadwal"), selectedColor: Colors.white),
          SalomonBottomBarItem(icon: Icon(Icons.menu_book), title: Text("Edukasi"), selectedColor: Colors.white),
          SalomonBottomBarItem(icon: Icon(Icons.bar_chart), title: Text("Grafik"), selectedColor: Colors.white),
          SalomonBottomBarItem(icon: Icon(Icons.person), title: Text("Profil"), selectedColor: Colors.white),
        ],
      ),
    );
  }

  Widget _buildMainDashboard(DashboardViewModel viewModel) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(viewModel.username),
          _buildJadwalPosyandu(),
          _buildDataAnak(viewModel),
          _buildEdukasiTerbaru(viewModel),
          _buildInformasiKesehatan(viewModel),
        ],
      ),
    );
  }

  Widget _buildHeader(String name) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Color(0xFF1976D2),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Hai, $name!", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
          Text("Yuk, pastikan kesehatan anak terjamin!", style: TextStyle(color: Colors.white)),
          const SizedBox(height: 12),
          TextField(
            decoration: InputDecoration(
              hintText: 'Ada yang bisa dibantu ?',
              hintStyle: TextStyle(color: Colors.blueGrey),
              filled: true,
              fillColor: Colors.white,
              prefixIcon: Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(30),
                borderSide: BorderSide.none,
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildJadwalPosyandu() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Jadwal Posyandu",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 12),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 6,
                  offset: Offset(0, 3),
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: const [
                      Icon(Icons.local_hospital, color: Color(0xFF2196F3)),
                      SizedBox(width: 12),
                      Text(
                        "Melati 29",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Divider(color: Colors.grey[300], thickness: 1),
                  const SizedBox(height: 12),
                  Row(
                    children: const [
                      Icon(Icons.calendar_today, color: Colors.black54, size: 20),
                      SizedBox(width: 12),
                      Text(
                        "Senin, 2 Desember 2024",
                        style: TextStyle(
                          fontSize: 15,
                          color: Colors.black87,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: const [
                      Icon(Icons.access_time, color: Colors.black54, size: 20),
                      SizedBox(width: 12),
                      Text(
                        "08:10 - 10:30",
                        style: TextStyle(
                          fontSize: 15,
                          color: Colors.black87,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }




  Widget _buildDataAnak(DashboardViewModel vm) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Data Anak",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 180, // Tinggi kartu
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: vm.children.length,
              separatorBuilder: (context, index) => const SizedBox(width: 12),
              itemBuilder: (context, index) {
                final child = vm.children[index];
                return Container(
                  width: 250,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 8,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        child.name,
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        "Tanggal Lahir: ${child.birthDate}",
                        style: TextStyle(color: Colors.grey[700], fontSize: 13),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        "Imunisasi: ${child.immunization}",
                        style: TextStyle(color: Colors.grey[700], fontSize: 13),
                      ),
                      const Spacer(),
                      Row(
                        children: [
                          _buildChip("${child.weight} kg", Colors.amber),
                          const SizedBox(width: 6),
                          _buildChip("${child.height} cm", Colors.blue),
                          const SizedBox(width: 6),
                          _buildChip("${child.headCircumference} cm", Colors.pink),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChip(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
      ),
    );
  }


  Widget _buildEdukasiTerbaru(DashboardViewModel vm) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text("Edukasi Terbaru", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 220,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: vm.educationItems.length,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemBuilder: (context, index) {
              final item = vm.educationItems[index];
              return Container(
                width: 240,
                margin: const EdgeInsets.only(right: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2)),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                      child: item.imageAssetPath != null
                          ? Image.asset(
                        item.imageAssetPath!,
                        height: 100,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      )
                          : Image.network(
                        item.imageUrl!,
                        height: 100,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                          const SizedBox(height: 4),
                          Text(item.description, maxLines: 2, overflow: TextOverflow.ellipsis),
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton(onPressed: () {}, child: const Text("Selengkapnya")),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildInformasiKesehatan(DashboardViewModel vm) {
    final imageSources = vm.healthImages;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("Informasi Kesehatan", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          SizedBox(
            height: 180,
            child: PageView.builder(
              controller: _pageController,
              itemCount: imageSources.length,
              itemBuilder: (context, index) {
                final item = imageSources[index];
                final isAsset = item.imageAssetPath != null;

                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: isAsset
                        ? Image.asset(item.imageAssetPath!, fit: BoxFit.cover, width: double.infinity)
                        : Image.network(item.imageUrl!, fit: BoxFit.cover, width: double.infinity),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: SmoothPageIndicator(
              controller: _pageController,
              count: imageSources.length,
              effect: WormEffect(dotHeight: 8, dotWidth: 8, activeDotColor: Colors.blue),
            ),
          ),
        ],
      ),
    );
  }
}
