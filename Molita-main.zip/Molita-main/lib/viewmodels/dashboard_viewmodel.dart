import 'package:flutter/material.dart';
import '../models/dashboard_model.dart';

class DashboardViewModel extends ChangeNotifier {
  String username = "Adel";

  List<ChildData> children = [
    ChildData(
      name: "Aulia Rahma",
      birthDate: "Senin, 2 Maret 2023",
      immunization: "POLIO",
      weight: 4.0,
      height: 60.0,
      headCircumference: 45.0,
    ),
    ChildData(name: "Siapa",
        birthDate: "Selasa, 1 Januari 2023",
        immunization: "wleawleo",
      weight: 5.0,
      height: 70.0,
      headCircumference: 45.0,)
  ];

  List<EducationItem> educationItems = [
    EducationItem(
      title: "Pentingnya Imunisasi",
      description: "Imunisasi melindungi anak dari penyakit berbahaya...",
      imageUrl: "https://st2.depositphotos.com/7863750/44093/i/450/depositphotos_440935102-stock-photo-beige-cat-doctor-face-mask.jpg",
    ),
    EducationItem(
      title: "Gizi Seimbang untuk Balita",
      description: "Pastikan si kecil mendapatkan asupan yang seimbang...",
      imageUrl: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/19/1e/4f/ca/photo1jpg.jpg?w=1400&h=800&s=1",
    ),
    EducationItem(
      title: "Cuci Tangan dengan Benar",
      description: "Langkah kecil untuk menjaga kebersihan dan kesehatan...",
      imageUrl: "https://assets.promediateknologi.id/crop/0x0:0x0/0x0/webp/photo/indizone/2022/05/11/WYsgrr8/aksi-pedagang-aduk-minuman-pakai-tangan-bikin-netizen-mual-kaya-kobokan-siapa-yang-mau58.jpg",
    ),
  ];

  List<HealthInfoImage> healthImages = [
  HealthInfoImage(imageAssetPath: 'assets/images/molita.png'),
  HealthInfoImage(imageUrl: 'https://picsum.photos/id/1025/600/300'),
  HealthInfoImage(imageAssetPath: 'assets/images/molita.png'),
  ];
}

