import 'package:flutter/material.dart';

class AppColors {
  static const Color softPink = Color(0xFFFFB8B8);
  static const Color brightBlue = Color(0xFF0071CF);
  static const Color mediumBlue = Color(0xFF1976D2);
}